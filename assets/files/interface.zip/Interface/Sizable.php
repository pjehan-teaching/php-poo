<?php

interface Sizable {
    
    public function getSize(): int;
    
}
